<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Data extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
        $this->load->library('encryption');
     
    }

    function index_get() { //get data kontak
        $email = $this->get('email');
        $password = $this->get('password');
        if ($email == '' ) {
           // $DataUser = $this->db->get('tbl_user')->result();
           $DataUser["ResponseCode"]="1";
         $DataUser["ResponseMessage"]="ERROR";
         $DataUser["error_msg"]="SILAHKAN MASUKAN EMAIL ANDA !";
         $this->response( $DataUser, 200);
        } else if ($password == '') {
            $DataUser["ResponseCode"]="1";
            $DataUser["ResponseMessage"]="ERROR";
            $DataUser["error_msg"]="SILAHKAN MASUKAN PASSWORD ANDA !";
            $this->response( $DataUser, 200);
        }else{
            $this->db->where('password',md5($password));
            $this->db->where('email',$email);
            $DataUser = $this->db->get('tbl_user')->result();


         if ($DataUser == null ){
            $DataUser["ResponseCode"]="1";
            $DataUser["ResponseMessage"]="SILAHKAN CEK EMAIL / PASSWORD ANDA !";
            $this->response( $DataUser, 200);
         }else {
   
            $this->db->where('password',md5($password));
            $this->db->where('email',$email);
            $this->db->select('tbl_user.id as id_user');
            $this->db->select('tbl_user.nama');
            $this->db->select('tbl_user.email');
             $this->db->select('tbl_user.no_telp');
            $this->db->select('m_role.role as Role');
            $this->db->join('m_role ','tbl_user.role = m_role.Kode_role' );
            $DataUser["ResponseCode"]="0";
            $DataUser["ResponseMessage"]="OK";
            $DataUser = $this->db->get('tbl_user')->result_array();

            $this->response(array('ResponseCode'=> 0 ,
          'ResponseMessage' => 'OK', "data"=>$DataUser));
            
         }
           
          
        }
        
      
    }

    function index_post() { // post data kontak
        date_default_timezone_set("Asia/Bangkok");
        $this->load->helper('date');

    $format = "%Y-%m-%d %h:%i %a";
       $data = array(
                   'nama'          => $this->post('nama'),
                   'email'    => $this->post('email'),
                    'no_telp'    => $this->post('no_telp'),
                   'password'    => md5($this->input->post("password")),
                   'role'    => $this->post('role'),
                   'created_date'    =>  mdate($format),
                   'created_by'    => 'ADMIN');
        $this->db->db_debug = false;
       $insert = $this->db->insert('tbl_user', $data);
       if ($insert ) {
        $this->response(array('ResponseCode'=> 0 ,
        'ResponseMessage' => 'OK', 'data' =>$data));
    
       } else {
           $this->response(array('ResponseCode'=> 1 ,
           'ResponseMessage' => 'email sudah pernah terdaftar silahkan masukan email yang berbeda !'));
       }
   }

   function index_put() { // update data kontak
     $id = $this->put('id');
     $data = array(
                //  'id'          => $this->put('id'),
                 'password'       => md5($this->put('password')));
                //  'password_real'          => $this->put('nama'),
                //  'email'    => $this->put('email'));
     $this->db->where('id', $id);
     $this->db->db_debug = false;
     $update = $this->db->update('tbl_user', $data);
     if ($update) {
        $this->response(array('ResponseCode'=> 0 ,
        'ResponseMessage' => 'OK' , 'data' => $data));
        //  $this->response($data, 200);
     } else {
        $this->response(array('ResponseCode'=> 1 ,
        'ResponseMessage' => 'id / email tidak ditemukan !'));
     }
 }

 function index_delete() { // delete data kontak
    $id = $this->delete('id');
    $this->db->where('id', $id);
    $delete = $this->db->delete('tbl_user');
    if ($delete) {
        $this->response(array('status' => 'success'), 201);
    } else {
        $this->response(array('status' => 'fail', 502));
    }
}

}
?>
